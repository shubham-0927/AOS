# AOS assignment 4

## Baby git 👶

### To execute the program

- Copy and paste mygit.cpp and make file into the folder you want to initialize git.
- Run:
```
make
```
- This will compile the code.

- To run program follow formate:
```
./mygit <command>
```
example:
```
./mygit init
```
- This will intialize the git the folder.