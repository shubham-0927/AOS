// #include <arpa/inet.h>
// #include <thread>
// #include <semaphore.h>
// #include <stdio.h>
// #include <stdlib.h>
// #include <string.h>
// #include <sys/socket.h>
// #include <unistd.h>

// #include<mutex>
// #include<iostream>
// #include<fcntl.h>
// #include<vector>
// #include<sstream>
// #include<unordered_map>
// using namespace std;


// #define CHUNK_SIZE 512
// #define SERVER_IP "127.0.0.1"
// #define SERVER_PORT 3000

// struct client_piece{
// 	int ip;
// 	int port;
// 	vector<int> piece;
// };
// struct client_login{
// 	int ip;
// 	int port;
// 	int name;
// 	int password;
// };

// struct file{
// 	vector<client_piece> client;  //client ->file
// 	string name;
// 	int sz;
// };
// unordered_map<string, string> users;  // Map to store client_id -> password
// unordered_map<string, vector<string>> groups;
// vector<pair<string,int>> trckr_info;
// mutex tracker_mutex;

// // Semaphore variables
// // sem_t x, y;
// // pthread_t tid;
// // pthread_t writerthreads[100];
// // pthread_t readerthreads[100];
// // int readercount = 0;


// void handle_client(int clientSocket) {
//     char buffer[4096];
//     bzero(buffer, 4096);

//     read(clientSocket, buffer, 4096);
//     string request(buffer);

//     tracker_mutex.lock();
// 	// lock_guard<mutex> lock(tracker_mutex);
//     string response;
// 	if(request.substr(0,11)=="create_user"){
// 		stringstream strs(request);
// 		string cmd, client_id,pass;
// 		strs>>cmd>>client_id>> pass;
// 		if (users.find(client_id) == users.end()) {
//             users[client_id] = pass;
//             response = "User created successfully: " + client_id;
//         } else {
//             response = "User already exists!";
//         }
// 		// response = " create client:"+client_id;


// 	}else if(request.substr(0,5) =="login"){
// 		stringstream strs(request);
// 		string cmd, client_id,pass;
// 		strs>>cmd>>client_id>> pass;
// 		if (users.find(client_id) != users.end() && users[client_id] == pass) {
//             response = "Login successful for client: " + client_id;
//         } else {
//             response = "Invalid credentials!";
//         }
// 	}else if(request.substr(0,12)=="create_group"){
// 		stringstream strs(request);
// 		string cmd, group_id;
// 		strs>>cmd >>group_id;
// 		if (groups.find(group_id) == groups.end()) {
//             groups[group_id] = {};  // Initialize an empty group
//             response = "Group created successfully: " + group_id;
//         }else{
//             response = "Group already exists!";
//         }
// 	}else{
// 		response = "cant do this try another request";
// 	}

//     write(clientSocket, response.c_str(), response.length());
//     tracker_mutex.unlock();
//     // close(clientSocket);
// }





// int main(int argc, char **argv)
// {

// 	if(argc<3){
// 		cout<<"use command example: ./tracker tracker_info.txt tracker_no \n";
// 		exit(1);
// 	}
// 	int trckr_id = stoi(argv[2]);
	
// 	int fd = open(argv[1], O_RDONLY);
//     if (fd == -1) {
//         cerr<<"Error opening tracker_info file \n";
//         exit(1);
//     }

//     char buffer[256];
//     int bytesRead;
//     string ip;
//     int port;
//     string content;

//     while ((bytesRead = read(fd, buffer, sizeof(buffer) - 1)) > 0) {
//         buffer[bytesRead] = '\0';
//         content += buffer;
//     }

//     if (bytesRead == -1) {
//         cerr<<"Error reading tracker_info file\n";
//         close(fd);
//         exit(1);
//     }

//     close(fd);
//     int pos = 0;
//     while ((pos = content.find('\n')) != string::npos) {
//         string line = content.substr(0, pos);
//         content.erase(0, pos + 1);

//         int colPos = line.find(' ');
//         if (colPos != string::npos) {
//             string ip = line.substr(0, colPos);
//             int port = stoi(line.substr(colPos + 1));
//             trckr_info.push_back({ip, port});
//         }
//     }

// 	if (trckr_id < 1 || trckr_id > trckr_info.size()) {
//         cerr<<"Invalid tracker number\n.";
//         exit(1);
//     }

// 	ip = trckr_info[trckr_id-1].first;
// 	port = trckr_info[trckr_id-1].second;
// 	cout<<"ip :"<<ip<<":"<<port<<'\n';
// 	int server_socket, clientSocket;
//     struct sockaddr_in server_addr, client_addr;
//     socklen_t client_len = sizeof(client_addr);

// 	server_socket = socket(AF_INET, SOCK_STREAM, 0);
//     if (server_socket < 0) {
//         cout<<"cant create socket.\n";
//         exit(1);
//     }

// 	bzero((char*)&server_addr, sizeof(server_addr));
//     server_addr.sin_family = AF_INET;
//     server_addr.sin_addr.s_addr = inet_addr(ip.c_str());
//     server_addr.sin_port = htons(port);

// 	int opt = 1;
// 	if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
// 		cerr<<"Error setting socket options.\n";
// 		close(server_socket);
// 		exit(1);
// 	}

// 	if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
//         cerr<<"Error on binding.\n";
//         close(server_socket);
//         exit(1);
//     }
// 	if (listen(server_socket, 5) == 0)
//         printf("Listening\n");
//     else
//         printf("Error\n"); //nomber of clients **************************
//     cout<<"Tracker listening on "<< ip<<":"<<port <<"\n";
// 	while (true) {
//         clientSocket = accept(server_socket, (struct sockaddr*)&client_addr, &client_len);
//         if (clientSocket < 0) {
//             cerr<<"Error on accept.\n";
//             continue;
//         }

//         thread client_thread(handle_client, clientSocket);
// 		close(clientSocket);
//         client_thread.detach();
//     }
//     close(server_socket);

// 	return 0;
// }









// #include <arpa/inet.h>
// #include <thread>
// #include <semaphore.h>
// #include <stdio.h>
// #include <stdlib.h>
// #include <string.h>
// #include <sys/socket.h>
// #include <unistd.h>

// #include<mutex>
// #include<iostream>
// #include<fcntl.h>
// #include<vector>
// #include<sstream>
// #include<unordered_map>
// using namespace std;

// #define CHUNK_SIZE 512
// #define SERVER_IP "127.0.0.1"
// #define SERVER_PORT 3000

// struct client_piece {
// 	int ip;
// 	int port;
// 	vector<int> piece;
// };

// struct client_login {
// 	int ip;
// 	int port;
// 	string name;
// 	string password;

// 	// Default constructor
// 	client_login() : ip(0), port(0), name(""), password("") {}

// 	// Parameterized constructor
// 	client_login(int ip_, int port_, string name_, string password_) {
// 		ip = ip_;
// 		port = port_;
// 		name = name_;
// 		password = password_;
// 	}
// };


// struct file {
// 	vector<client_piece> client;  // Client -> File
// 	string name;
// 	int sz;
// };

// unordered_map<string, string> users;  // Map to store client_id -> password
// unordered_map<string, vector<string>> groups;
// unordered_map<string, client_login> clients;  // Map to store client info by their client_id
// vector<pair<string,int>> trckr_info;
// mutex tracker_mutex;

// // Function to log client information to the tracker terminal
// void log_client_info(const string& action, const string& client_id, int client_port) {
// 	cout<< "Client "<<action<<": "<<client_id<<" (Port: "<<client_port<<")\n";
// }

// void handle_client(int clientSocket, int client_port) {
//     char buffer[4096];
//     bzero(buffer, 4096);

//     int n = read(clientSocket, buffer, 4096);
// 	if (n < 0) {
//     cerr<<"Error reading from socket.\n";
//     close(clientSocket);
//     return;
// }
//     string request(buffer);

//     tracker_mutex.lock();
//     string response;
//     if (request.substr(0, 11) == "create_user") {
//         stringstream strs(request);
//         string cmd, client_id, pass;
//         strs>>cmd>>client_id>>pass;
        
//         if (users.find(client_id) == users.end()) {
//             users[client_id] = pass;
//             clients[client_id] = {inet_addr(SERVER_IP), client_port, client_id, pass};
// // 			client_login login_info;
// // login_info.ip = inet_addr(SERVER_IP);
// // login_info.port = client_port;
// // login_info.name = client_id;
// // login_info.password = pass;

// // clients[client_id] = login_info; 



//  // Store client info
//             response = "User created successfully: " + client_id;
//             log_client_info("created", client_id, client_port);  // Log to tracker terminal
//         } else {
//             response = "User already exists!";
//         }
//     } else if (request.substr(0, 5) == "login") {
//         stringstream strs(request);
//         string cmd, client_id, pass;
//         strs>>cmd>>client_id>>pass;
        
//         if (users.find(client_id) != users.end() && users[client_id] == pass) {
//             response = "Login successful for client: " + client_id;
//             log_client_info("logged in", client_id, client_port);  // Log to tracker terminal
//         } else {
//             response = "Invalid credentials!";
// 			cout<<"invalid credentials"<<flush;
//         }
//     } else if (request.substr(0, 12) == "create_group") {
//         stringstream strs(request);
//         string cmd, group_id;
//         strs>>cmd>>group_id;
        
//         if (groups.find(group_id) == groups.end()) {
//             groups[group_id] = {};  // Initialize an empty group
//             response = "Group created successfully: " + group_id;
//             cout<< "Group created: "<<group_id<<"\n";  // Log to tracker terminal
//         } else {
//             response = "Group already exists!";
//         }
//     } else {
//         response = "Cannot process this request, try another.";
//     }

    
// int a=write(clientSocket, response.c_str(), response.length());
// 	if (a < 0) {
//     cerr<<"Error writing to socket.\n";
// }
//     tracker_mutex.unlock();
// }

// int main(int argc, char **argv) {
// 	if (argc < 3) {
// 		cout<< "Usage: ./tracker tracker_info.txt tracker_no\n";
// 		exit(1);
// 	}

// 	int trckr_id = stoi(argv[2]);
// 	int fd = open(argv[1], O_RDONLY);
//     if (fd == -1) {
//         cerr<<"Error opening tracker_info file\n";
//         exit(1);
//     }

//     char buffer[256];
//     int bytesRead;
//     string ip;
//     int port;
//     string content;

//     while ((bytesRead = read(fd, buffer, sizeof(buffer) - 1)) > 0) {
//         buffer[bytesRead] = '\0';
//         content += buffer;
//     }

//     if (bytesRead == -1) {
//         cerr<<"Error reading tracker_info file\n";
//         close(fd);
//         exit(1);
//     }

//     close(fd);
//     int pos = 0;
//     while ((pos = content.find('\n')) != string::npos) {
//         string line = content.substr(0, pos);
//         content.erase(0, pos + 1);

//         int colPos = line.find(' ');
//         if (colPos != string::npos) {
//             string ip = line.substr(0, colPos);
//             int port = stoi(line.substr(colPos + 1));
//             trckr_info.push_back({ip, port});
//         }
//     }

// 	if (trckr_id < 1 || trckr_id > trckr_info.size()) {
//         cerr<<"Invalid tracker number.\n";
//         exit(1);
//     }

// 	ip = trckr_info[trckr_id - 1].first;
// 	port = trckr_info[trckr_id - 1].second;
// 	cout<< "Tracker listening on IP: "<<ip<<" Port: "<<port<<'\n';

// 	int server_socket, clientSocket;
//     struct sockaddr_in server_addr, client_addr;
//     socklen_t client_len = sizeof(client_addr);

// 	server_socket = socket(AF_INET, SOCK_STREAM, 0);
//     if (server_socket < 0) {
//         cerr<<"Error creating socket.\n";
//         exit(1);
//     }

// 	bzero((char*)&server_addr, sizeof(server_addr));
//     server_addr.sin_family = AF_INET;
//     server_addr.sin_addr.s_addr = inet_addr(ip.c_str());
//     server_addr.sin_port = htons(port);

// 	int opt = 1;
// 	if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
// 		cerr<<"Error setting socket options.\n";
// 		close(server_socket);
// 		exit(1);
// 	}

// 	if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
//         cerr<<"Error on binding.\n";
//         close(server_socket);
//         exit(1);
//     }

// 	if (listen(server_socket, 5) == 0)
//         cout<< "Listening...\n";
//     else
//         cerr<<"Error on listen.\n";

// 	while (true) {
// 		cout<<"inside while\n"<<flush;
//         clientSocket = accept(server_socket, (struct sockaddr*)&client_addr, &client_len);
//         if (clientSocket < 0) {
//             cout<< "Error on accept.\n";
//             continue;
//         }

//         int client_port = ntohs(client_addr.sin_port);  // Get client's port
//         thread client_thread(handle_client, clientSocket, client_port);
// 		client_thread.detach();  // Detach thread to handle independently
//     }

//     close(server_socket);
// 	return 0;
// }




#include <arpa/inet.h>
#include <thread>
#include <fcntl.h>
#include <unistd.h>
#include <iostream>
#include <sstream>
#include <string.h>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <sys/socket.h>
#include <unordered_set>
#include <queue>
#include <set>
#include <random>

using namespace std;

#define BUFFER_SIZE 2048
#define CHUNK_SIZE (1024 * 1024)

struct client_piece {
    string ip; 
    int port;
    vector<int> piece;
};

struct client_login {
    string ip; 
    int port;
    string name;
    string password;
};

struct ClientInfo {
    int ip;
    int port;
    string username;
    string password;

    ClientInfo() : ip(0), port(0), username(""), password("") {}

    ClientInfo(int ip_, int port_, string username_, string password_) {
        ip = ip_;
        port = port_;
        username = username_;
        password = password_;
    }
};
struct node_info {
    string node_ip;
    int node_port;
    node_info() : node_ip(""), node_port(0) {}
    
    node_info(string ip_, int port_) {
        node_ip = ip_;
        node_port = port_;
    }
};



struct GroupInfo {
    string owner;                 
    unordered_set<string> members;
    queue<string> join_requests;  
};


struct file_info {
    string file_name;
    string file_hash;
    long long file_size;
    unordered_set<string> users;
};

struct file_piece_info {
    
    unordered_map<string, set<int>> user_pieces;  
    long long total_pieces;
};


unordered_map<string, node_info> node_comm_info;
unordered_map<string, string> users;  // Username -> Password
unordered_map<string, ClientInfo> logged_in_clients;  // Username -> Client Info
unordered_map<string, GroupInfo> groups;
unordered_set<string> active_users;
unordered_map<string, client_login> clients;  
vector<pair<string, int>> tracker_info;  

unordered_map<string, unordered_map<string, file_info>> group_files;

unordered_map<string, unordered_map<string, file_piece_info>> group_file_pieces; 

set<int> used_tokens;
unordered_map<int,string> tok_user;
mutex m;
mutex tracker_mutex; 
bool f = false;
int generate_unique_token() {
    random_device rd; 
    mt19937 gen(rd());
    uniform_int_distribution<> dis(10, 99); 

    int token;
    do {
        token = dis(gen);
    } while (used_tokens.find(token) != used_tokens.end());

    used_tokens.insert(token);
    return token;
}



void server_logs(string event) {
    cout<<event<<'\n';
}
void log_client_info(string action, string client_id) {
    cout<<"Client "<<action <<": " <<client_id <<'\n';
}
string get_username_from_port(int clientPort) {
    for ( auto& entry : logged_in_clients) {
        if (entry.second.port == clientPort) {
            return entry.first;  
        }
    }
    return "";  
}

string get_username_from_tok(int tok) {
    if (tok_user.find(tok) != tok_user.end()) {
        return tok_user[tok];
    } else {
        return ""; 
    }
}

void handle_download_request(string request, string& response, int clientPort) {
    stringstream ss(request);
    string tok,cmd, group_id, file_name, destpath;
    ss >>tok>>cmd>>group_id>>file_name>>destpath;

    string username = get_username_from_port(clientPort); 
    username = get_username_from_tok(stoi(tok)); 
    cout<<"🧑‍💻 user: "<<username<<" asking for files\n";
    if (groups.find(group_id) == groups.end()) {
        response = "🔴 Group not found!";
        return;
    }
    if (groups[group_id].members.find(username) == groups[group_id].members.end()) {
        response = "❌ You are not a member of this group!";
        return;
    }

    // tracker_mutex.lock();

    if (group_file_pieces[group_id].find(file_name) == group_file_pieces[group_id].end()) {
        response = "🔴 File not found in this group!";
        // tracker_mutex.unlock();
        return;
    }
    cout<<"\n File: "<<file_name<<" found\n";
    file_piece_info& piece_info = group_file_pieces[group_id][file_name];
    file_info& file = group_files[group_id][file_name];

    response = group_id + "|" + file_name + "|" + to_string(file.file_size) + "|" + file.file_hash;

    for ( auto& [user, pieces] : piece_info.user_pieces) {
        if (node_comm_info.find(user) != node_comm_info.end()) {
             node_info& node = node_comm_info[user];
            response += "|" + user + "," + node.node_ip + ":" + to_string(node.node_port) + ",";
            
            for ( int piece_num : pieces) {
                response += to_string(piece_num) + ":";  
            }
            if (!pieces.empty()) {
                response.pop_back();
            }
        }
    }

    cout<<"🟢 Send file details related to file: "<< file_name<<'\n'<<flush;
    // tracker_mutex.unlock();
    return;
}

void to_remove_filename(string request, int clientPort, string& response) {
    stringstream ss(request);
    string tok, cmd, group_id, file_name;
    ss>>tok>>cmd>>group_id>> file_name;
    string username = get_username_from_port(clientPort);
    username = get_username_from_tok(stoi(tok));

    tracker_mutex.lock();
    if (groups.find(group_id) == groups.end() || groups[group_id].members.find(username) == groups[group_id].members.end()) {
        response = "🔴 You are not a member of this group!";
        tracker_mutex.unlock();
        return;
    }
    if (group_files[group_id].find(file_name) == group_files[group_id].end()) {
        response = "🔴 File '" + file_name + "' does not exist in group " + group_id;
        tracker_mutex.unlock();
        return;
    }
    file_info& f_info = group_files[group_id][file_name];
    if (f_info.users.find(username) == f_info.users.end()) {
        response = "🔴 You are not associated with the file '" + file_name + "' in group " + group_id;
        tracker_mutex.unlock();
        return;
    }
    f_info.users.erase(username);
    group_file_pieces[group_id][file_name].user_pieces.erase(username);
    if (f_info.users.empty()) {
        group_files[group_id].erase(file_name);
        group_file_pieces[group_id].erase(file_name);
        response = "🟢 File '" + file_name + "' has been removed completely from group " + group_id;
        cout<<"File '"<<file_name<<"' removed from group "<<group_id<<" as no users are sharing it anymore.\n";
    } else {
        response = "🟢 You have stopped sharing the file '" + file_name + "' in group " + group_id;
        cout<<"User "<<username<<" has stopped sharing file '"<<file_name<<"' in group "<<group_id<<".\n";
    }
    tracker_mutex.unlock();
}

void handle_upload_request(string request, int clientPort, string& response) {
    stringstream ss(request);
    string tok,cmd, file_name, file_size_str, concatenated_hash, group_id;
    ss >>tok>>cmd>>file_name>>file_size_str>>concatenated_hash>>group_id;
    string username = get_username_from_port(clientPort);
    username = get_username_from_tok(stoi(tok));
    tracker_mutex.lock();

    // Check if the group exists
    if (groups.find(group_id) == groups.end() || groups[group_id].members.find(username) == groups[group_id].members.end()) {
        response = "🔴 You are not a member of this group!";
        tracker_mutex.unlock();
        return;
    }

    // if (group_files.find(group_id) == group_files.end()) {
    //     group_files[group_id] = unordered_map<string, file_info>();  // Create a new group entry if not exists
    // }

    if (group_files[group_id].find(file_name) == group_files[group_id].end()) {
        file_info fi = {file_name, concatenated_hash,stoi(file_size_str), {username}};
        group_files[group_id][file_name] = fi;
        response = "🟢 File uploaded successfully: " + file_name + " to group " + group_id;
        cout<<"New file '"<<file_name<<"' uploaded to group "<<group_id<<" by user "<<username<<"\n";
    } else {
        file_info& f_info = group_files[group_id][file_name];
        if (f_info.users.find(username) == f_info.users.end()) {
            // Add user to the set of users who have uploaded the file
            f_info.users.insert(username);
            response = "🟢 File uploaded successfully: " + file_name + " to group " + group_id;
        cout<<"New file '"<<file_name<<"' uploaded to group "<<group_id<<" by user "<<username<<"\n";
            // response = "🔴 File already exists. User " + username + " associated with file: " + file_name;
            // cout<<"User "<<username<<" associated with file '"<<file_name<<"' in group "<<group_id<<"\n";
        } else {
            response = "File already uploaded by this user.";
        }
    }
    long long total_pieces = (stoi(file_size_str) + CHUNK_SIZE - 1) / CHUNK_SIZE;
    set<int> all_pieces;
    for (long long i = 0; i < total_pieces; ++i) {
        all_pieces.insert(i);
    }

    group_file_pieces[group_id][file_name].user_pieces[username] = all_pieces;
    group_file_pieces[group_id][file_name].total_pieces = total_pieces;

    tracker_mutex.unlock();
}

void handle_list_files_request(string request, int clientPort, string& response) {
    stringstream ss(request);
    string tok,cmd, group_id;
    ss>>tok>>cmd>>group_id;

    string username = get_username_from_port(clientPort); 
    username = get_username_from_tok(stoi(tok));
    cout<<"\n tok:"<<stoi(tok)<<'\n';
    tracker_mutex.lock();
    if (groups.find(group_id) == groups.end() || groups[group_id].members.find(username) == groups[group_id].members.end()) {
        response = "❌  "+ username + " You are not a member of this group!";
        tracker_mutex.unlock();
        return;
    } else {
        GroupInfo& group_info = groups[group_id];
        if (group_info.members.find(username) == group_info.members.end()) {
            response = "You are not a member of this group!";
        } else {
            unordered_map<string, file_info>& files_in_group = group_files[group_id];
            if (files_in_group.empty()) {
                response = "No files found in group: " + group_id;
            } else {
                stringstream response_stream;
                response_stream<<"Files in group "<<group_id<<":\n";

                for ( auto& file_pair : files_in_group) {
                     file_info& f_info = file_pair.second;
                    response_stream<<"File: "<<f_info.file_name<<"\n";
                    response_stream<<"Uploaded by users: ";

                    for ( auto& user : f_info.users) {
                        response_stream<<user<<" ";
                    }
                    response_stream<<"\n";
                }

                response = response_stream.str();
            }
        }
    }

    tracker_mutex.unlock();
}

void sync_receive(int sockfd) {
    char buffer[CHUNK_SIZE];
    stringstream ss;
    
    while (true) {
        long long n = recv(sockfd, buffer, sizeof(buffer) - 1, 0);
        if (n <= 0) {
            cerr<<"🔴 Error receiving sync data or connection closed.\n";
            break;
        }
        
        buffer[n] = '\0';
        ss<<buffer;
        string line;
        
        while (getline(ss, line)) {
            stringstream line_stream(line);
            string type;
            getline(line_stream, type, '|');

            if (type == "sync_node") {
                string node_name, node_ip;
                int node_port;
                getline(line_stream, node_name, '|');
                getline(line_stream, node_ip, '|');
                line_stream>>node_port;
                
                lock_guard<mutex> lock(tracker_mutex);
                node_comm_info[node_name] = {node_ip, node_port};

            } else if (type == "sync_user") {
                string username, password;
                getline(line_stream, username, '|');
                getline(line_stream, password, '|');
                
                lock_guard<mutex> lock(tracker_mutex);
                users[username] = password;

            } else if (type == "sync_client") {
                string username, ip;
                int port;
                getline(line_stream, username, '|');
                getline(line_stream, ip, '|');
                line_stream>>port;
                
                lock_guard<mutex> lock(tracker_mutex);
                logged_in_clients[username] = {inet_addr(ip.c_str()), port, username, users[username]};  // Assume password is already synced

            } else if (type == "sync_group") {
                string group_id, owner;
                getline(line_stream, group_id, '|');
                getline(line_stream, owner, '|');
                
                lock_guard<mutex> lock(tracker_mutex);
                groups[group_id].owner = owner;

            } else if (type == "sync_file") {
                string group_id, file_name, file_hash;
                getline(line_stream, group_id, '|');
                getline(line_stream, file_name, '|');
                getline(line_stream, file_hash, '|');
                
                lock_guard<mutex> lock(tracker_mutex);
                group_files[group_id][file_name].file_hash = file_hash;

            } else if (type == "sync_piece") {
                string group_id, file_name;
                int total_pieces;
                getline(line_stream, group_id, '|');
                getline(line_stream, file_name, '|');
                line_stream>>total_pieces;
                
                lock_guard<mutex> lock(tracker_mutex);
                group_file_pieces[group_id][file_name].total_pieces = total_pieces;

            } else if (type == "sync_token") {
                int token;
                string username;
                line_stream>>token;
                getline(line_stream, username, '|');
                
                lock_guard<mutex> lock(tracker_mutex);
                used_tokens.insert(token);
                tok_user[token] = username;
            }
        }
        
        ss.clear();  // Clear the stringstream buffer for future data
    }
    
    close(sockfd);  // Close socket when done
}
void trackerReqs(string totracker){
    string cmd_track, sender_ip, request, clientIp,tokenstring;
    int sender_port, clientPort;
    stringstream ss(totracker);
    ss>>cmd_track;  
    ss>>clientIp;
    ss>>clientPort;
    ss>>sender_ip;   
    ss>>sender_port; 
    ss>> tokenstring;
    int token_int = stoi(tokenstring);
    getline(ss, request);
    if (!request.empty() && request[0] == ' ') {
        request = request.substr(1);
    }
    m.lock();
        if (request.substr(3, 11) == "create_user") {
            stringstream strs(request);
            string tok,cmd, username, password;
            strs>>tok>>cmd>>username>>password;

            if (users.find(username) == users.end()) {
                users[username] = password;
                clients[username] = {username, 0, username, password};
            }

        }else if (request.substr(3, 5) == "login") {
                stringstream strs(request);
                string tok,cmd, username, password;
                strs>>tok>>cmd>>username>>password;
                int tok_int = stoi(tok);
                int token;
                if (tok=="00" && users.find(username) != users.end() && users[username] == password) {
                    if (active_users.find(username) == active_users.end()){
                        string s ;
                        s = tok_user[tok_int];
                        if(s.length()==0){
                            active_users.insert(username);
                            // token = generate_unique_token();
                            tok_user[token_int] = username;
                            logged_in_clients[username] = {inet_addr(clientIp.data()), clientPort, username, password};
                            cout<<"\n🟢 Login successful for user: "<< username<<"\n";
                        }
                    }
                }

        }else if (request.substr(3, 6) == "logout") {
            stringstream strs(request);
            string tok,cmd;
            strs >>tok>> cmd;
            string username = tok_user[stoi(tok)];
            if (active_users.find(username) != active_users.end()) {
                active_users.erase(username);
                logged_in_clients.erase(username);
                tok_user.erase(stoi(tok));
                used_tokens.erase(stoi(tok));
            }
        }else if (request.substr(3, 12) == "create_group") {
            stringstream strs(request);
            string tok,cmd, group_id;
            strs>>tok>>cmd>>group_id;

            if (groups.find(group_id) == groups.end()) {
                GroupInfo group_info;
                string username = get_username_from_port(clientPort);
                username = get_username_from_tok(stoi(tok));      
                if (!username.empty()) {
                    group_info.owner = username;
                    group_info.members.insert(username); 
                    groups[group_id] = group_info;  
                    group_files[group_id] = unordered_map<string, file_info>();
                }
            }

        }else if(request.substr(3,10)=="join_group"){
            stringstream strs(request);
            string tok,cmd, group_id;
            strs>>tok>> cmd>>group_id;
            if(groups.find(group_id)!= groups.end()){
                GroupInfo group_info;
                string username = get_username_from_port(clientPort);
                username = get_username_from_tok(stoi(tok));
                if(!username.empty()){
                    groups[group_id].join_requests.push(logged_in_clients[username].username);

                }
            }
        }else if(request.substr(3,11) == "leave_group") {
            stringstream strs(request);
            string tok,cmd, group_id;
            strs>>tok>> cmd>>group_id;
            if(groups.find(group_id) != groups.end()) {
                GroupInfo& group_info = groups[group_id];  
                string username = get_username_from_port(clientPort);
                username = get_username_from_tok(stoi(tok));
                if(!username.empty()) {
                    auto member_it = group_info.members.find(username);
                    if(member_it != group_info.members.end()) {
                        if(group_info.owner == username) {
                            if(group_info.members.size() > 1) {
                                group_info.members.erase(username);  
                                group_info.owner = *group_info.members.begin(); 
                            }
                        }
                    } 
                }
            }
        }else if(request.substr(3, 13) == "list_requests"){
            stringstream strs(request);
            string tok, cmd, group_id;
            strs>>tok>>cmd>>group_id;
            if(groups.find(group_id)!= groups.end()){
                GroupInfo group_info;
                string username = get_username_from_port(clientPort);
                username = get_username_from_tok(stoi(tok));
                if(!username.empty()){
                    if(groups[group_id].owner == logged_in_clients[username].username){
                        
                        while (!groups[group_id].join_requests.empty()) {
                            groups[group_id].join_requests.pop();
                        }
                    }
                }
            }
        }else if(request.substr(3, 14) == "accept_request"){
            stringstream strs(request);
            int tok_int;
            string tok,cmd,group_id, uesr_id;
            strs>>tok>>cmd >>group_id>> uesr_id;
            tok_int= stoi(tok);
            if(groups.find(group_id)!= groups.end()){
                GroupInfo group_info;
                string username = get_username_from_port(clientPort);
                username = get_username_from_tok(tok_int);
                if(!username.empty()){
                    if(groups[group_id].owner == logged_in_clients[username].username){
                        groups[group_id].members.insert(uesr_id);
                    }
                }
            }
        }
        else if (request.substr(3, 11) == "upload_file") {
            string s = "";
            handle_upload_request(request, clientPort, s);
        }else if(request.substr(3,10)=="stop_share"){
            string s ="";
            to_remove_filename(request,clientPort,s);
        }
        else if (request.substr(0, 4) == "exit"){
            cout<<"✅ IP"<< clientIp<<":"<<clientPort<<"stoped\n";
        }
        m.unlock();
        
        
}

int clientReqs(int clientSocket, int clientPort, char *clientIp, string current_ip, int current_port) {
    char buffer[CHUNK_SIZE];
   

    while(true){
        bzero(buffer, CHUNK_SIZE);
        // cout<<"whle handle client\n";
        int n = recv(clientSocket, buffer, CHUNK_SIZE,0);
        if (n <= 0) {
            cerr<<"🔴 Error reading from socket\n";
            close(clientSocket);
            return 1;
            // continue;
        }
        int token;
        string request(buffer);
        string response;
        string dclientip(clientIp);
        
        // Process request
        // cout<<"🔄 Before lock";
        // m.lock();
        // cout<<"🔄 After lock";
        if (request.substr(3, 11) == "create_user") {
            stringstream strs(request);
            string tok,cmd, username, password;
            strs>>tok>>cmd>>username>>password;

            if (users.find(username) == users.end()) {
                users[username] = password;
                // logged_in_clients[username] = {inet_addr(clientIp), clientPort, username, password};  
                clients[username] = {username, 0, username, password};
                response = "User created successfully: " + username;
                
                server_logs("User created: " + username + " (Port: " + to_string(clientPort) + ")");
            } else {
                response = "🔴 User already exists!";
                server_logs("🔴  User creation failed: " + username + " already exists.");
            }

        } else if (request.substr(3, 7) == "my_port") {
                stringstream strs(request);
                string tok,cmd, ip_port;
                strs>> tok>>cmd>>ip_port;

                // Split ip_port into IP and Port
                long long colon_pos = ip_port.find(':');
                if (colon_pos != string::npos) {
                    string node_ip = ip_port.substr(0, colon_pos);
                    int node_port = stoi(ip_port.substr(colon_pos + 1));

                    string s = get_username_from_port(clientPort);
                    if(tok!="00")s = get_username_from_tok(stoi(tok));
                    if (!s.empty() &&clients.find(s) != clients.end()) {
                        node_comm_info[s] = node_info(node_ip, node_port);
                        response = "🟢 Node communication info saved for " + s + ": " + node_ip + ":" + to_string(node_port);
                    } else {
                        response = "Client ID not found. Please log in first.";
                    }
                } else {
                    response = "Invalid IP:Port format. Please use 'my_port <IP:Port>'.";
                }
        }else if (request.substr(3, 5) == "login") {
                stringstream strs(request);
                string tok,cmd, username, password;
                strs>>tok>>cmd>>username>>password;
                int tok_int = stoi(tok);
                
                if (users.find(username) != users.end() && users[username] == password) {
                    if (active_users.find(username) == active_users.end()){
                        string s = get_username_from_port(clientPort);
                        s = tok_user[tok_int];
                        if(s.length()==0){
                            active_users.insert(username);
                            token = generate_unique_token();
                            tok_user[token] = username;
                            logged_in_clients[username] = {inet_addr(clientIp), clientPort, username, password};
                            response =to_string(token) + "|🟢 Login successful for client: " + username;
                            server_logs("🟢 Login successful for user: " + username + " (Port: " + to_string(clientPort) + ")");
                        }
                        else{
                            response = tok+ "|🔴 currently user :"+s+" is logged in";
                            server_logs("🔴 Failed another login of user");
                        }

                    }else{
                        response = tok+"|🔴 User is already logged in!";
                        server_logs("🔴 Login failed: " + username + " is already logged in.");
                    }
                } else {
                    response = tok+ "|🔴 Invalid credentials!";
                    server_logs("🔴  Login failed for user: " + username + " (Port: " + to_string(clientPort) + ")");
                }

        }else if (request.substr(3, 6) == "logout") {
            stringstream strs(request);
            string tok,cmd;
            strs >>tok>> cmd;
            // string username = get_username_from_port(clientPort);
            string username = tok_user[stoi(tok)];
            if (active_users.find(username) != active_users.end()) {
                active_users.erase(username);
                logged_in_clients.erase(username);
                tok_user.erase(stoi(tok));
                used_tokens.erase(stoi(tok));
                response = "🟢 Logout successful for client: " + username;
                server_logs("🟢 Logout successful for user: " + username + " (Port: " + to_string(clientPort) + ")");
            } else {
                response = "🔴 User is not logged in!";
                server_logs("🔴 Logout failed: " + username + " is not logged in.");
            }
        }else if (request.substr(3, 12) == "create_group") {
            stringstream strs(request);
            string tok,cmd, group_id;
            strs>>tok>>cmd>>group_id;

            if (groups.find(group_id) == groups.end()) {
                GroupInfo group_info;
                string username = get_username_from_port(clientPort);
                username = get_username_from_tok(stoi(tok));      
                if (!username.empty()) {
                    group_info.owner = username;
                    group_info.members.insert(username); 
                    groups[group_id] = group_info;  
                    group_files[group_id] = unordered_map<string, file_info>();
                    response = "🟢  Group created successfully: " + group_id;
                    server_logs("🟢  Group created by user: " + username);
                } else {
                    response = "🔴 Error: Could not find the user associated with this port!";
                    server_logs("🔴 Group creation failed: No user associated with port " + to_string(clientPort)+" and token: "+tok);
                }

            } else {
                response = "🟡  Group already exists!";
                server_logs("🟡  Group creation failed: " + group_id + " already exists.");
            }

        }else if(request.substr(3,10)=="join_group"){
            stringstream strs(request);
            string tok,cmd, group_id;
            strs>>tok>> cmd>>group_id;
            if(groups.find(group_id)!= groups.end()){
                GroupInfo group_info;
                string username = get_username_from_port(clientPort);
                username = get_username_from_tok(stoi(tok));
                if(!username.empty()){
                    groups[group_id].join_requests.push(logged_in_clients[username].username);
                    response = "🕒 Join  request sent for group: "+ group_id;
                    server_logs("🟡 user "+logged_in_clients[username].username+" requesting for group join the group id:"+ group_id);

                }else{
                    response = "🔴  Error: Could not find the user associated with this port!";
                    server_logs("🔴  Group join failed: No group owner associated with port " + to_string(clientPort));
                }
                
            }else{
                response = "Group does not exists";
                server_logs("🔴  join request failed for group id:"+ group_id);
            }
        }else if(request.substr(3,11) == "leave_group") {
            stringstream strs(request);
            string tok,cmd, group_id;
            strs>>tok>> cmd>>group_id;
            if(groups.find(group_id) != groups.end()) {
                GroupInfo& group_info = groups[group_id];  
                
                
                string username = get_username_from_port(clientPort);
                username = get_username_from_tok(stoi(tok));
                if(!username.empty()) {
                    auto member_it = group_info.members.find(username);
                    if(member_it != group_info.members.end()) {
                        if(group_info.owner == username) {
                            if(group_info.members.size() > 1) {
                                group_info.members.erase(username);  
                                group_info.owner = *group_info.members.begin(); 
                                response = "🟢 You have left the group, and ownership has been transferred to " + group_info.owner;
                                server_logs("🟢 User " + username + " left and transferred ownership to " + group_info.owner);
                            } else {
                                groups.erase(group_id);
                                response = "🟢 You have left the group. No other members, group deleted.";
                                server_logs("🟢 User " + username + " left and group " + group_id + " deleted due to no members.");
                            }
                        } else {
                            group_info.members.erase(username);
                            response = "🟢 You have left the group: " + group_id;
                            server_logs("🟢 User " + username + " left group " + group_id);
                        }
                    } else {
                        response = "🔴 Error: You are not a member of group " + group_id;
                        server_logs("🔴 User " + username + " attempted to leave a group they are not part of: " + group_id);
                    }
                } else {
                    response = "🔴 Error: Could not find the user associated with this port!";
                    server_logs("🔴 Leave group failed: No user associated with port " + to_string(clientPort));
                }
            } else {
                response = "🔴 Group does not exist!";
                server_logs("🔴 Leave group failed: Group " + group_id + " does not exist.");
            }
        }else if(request.substr(3, 13) == "list_requests"){
            stringstream strs(request);
            string tok, cmd, group_id;
            strs>>tok>>cmd>>group_id;
            if(groups.find(group_id)!= groups.end()){
                GroupInfo group_info;
                string username = get_username_from_port(clientPort);
                username = get_username_from_tok(stoi(tok));
                if(!username.empty()){
                    if(groups[group_id].owner == logged_in_clients[username].username){
                        response = "Join requests for group " + group_id + ":\n";
                        while (!groups[group_id].join_requests.empty()) {
                            response += groups[group_id].join_requests.front() + "\n";
                            groups[group_id].join_requests.pop();
                        }
                        server_logs("🧑‍💻 Owner " + logged_in_clients[username].username + " checked join requests for group: " + group_id);
                    }else {
                        response = "You are not the owner of this group or group does not exist!";
                        server_logs("🔴 Join request listing failed for user: " + logged_in_clients[username].username);
                    }
                }else{
                    response = "Error: Could not find the user associated with this port!";
                    server_logs("🔴 Group list request failed: No user associated with port " + to_string(clientPort));
                }
            }else{
                response = "Group does not exists";
                server_logs("🔴 join request failed for group id:"+ group_id);
            }
        }else if(request.substr(3, 14) == "accept_request"){
            stringstream strs(request);
            int tok_int;
            string tok,cmd,group_id, uesr_id;
            strs>>tok>>cmd >>group_id>> uesr_id;
            tok_int= stoi(tok);
            if(groups.find(group_id)!= groups.end()){
                GroupInfo group_info;
                string username = get_username_from_port(clientPort);
                username = get_username_from_tok(tok_int);
                if(!username.empty()){
                    if(groups[group_id].owner == logged_in_clients[username].username){
                        groups[group_id].members.insert(uesr_id);
                        response = "🟢 User " + uesr_id + " added to group: " + group_id;
                        server_logs("🟢  User " + uesr_id + " accepted into group: " + group_id);
                    }else {
                        response = "You are not the owner of this group or group does not exist!";
                        server_logs("Join request listing failed for user: " + logged_in_clients[username].username);
                    }
                }else{
                    response = "Error: Could not find the user associated with this port!";
                    server_logs("Group creation failed: No user associated with port " + to_string(clientPort));
                }
            }
        }else if(request.substr(3,11)== "list_groups"){
            if(!groups.empty()){
                response ="🔄  Listing All Group In Network:\n";
                for(auto& it: groups){
                    response+=it.first+ "\n";
                }
                server_logs("✅  Send group details to client on port :"+to_string(clientPort));
            }else{
                response = "❌ Currently no Groups in network";
                server_logs("❌ No groups in network as list_group query by port "+to_string(clientPort));
            }
        }else if (request.substr(3, 10) == "list_files") {
            handle_list_files_request(request, clientPort, response);
        }
        else if (request.substr(3, 11) == "upload_file") {
            handle_upload_request(request, clientPort, response);
        }else if (request.substr(3, 13) == "download_file"){
            handle_download_request(request,response,clientPort);
        }else if(request.substr(3,10)=="stop_share"){
            to_remove_filename(request,clientPort,response);
        }
        else if (request.substr(0, 4) == "exit"){
            cout<<"✅ socket number "<< clientSocket<<":"<<clientPort<<"stoped\n";
            response="✅ bye user at "+clientSocket;
        }else if(request.substr(0,12)=="sync_tracker"){
            
            trackerReqs(request);
            cout<<"🔄 Tracker sync \n";
            // m.unlock();
            continue;
        } 
        else {
            response = "🔴 Invalid request!";
            server_logs("🔴 Invalid request received from client.");
            // break;
        }
        
        // m.unlock();
        long long a = write(clientSocket, response.c_str(), response.length());
        if (a < 0) {
            cerr<<"🔴 Error writing to socket\n";
            close(clientSocket);
            return 1;
        }


        string totracker = "sync_tracker "+dclientip+" "+to_string(clientPort)+" " +current_ip+" "+to_string(current_port)+" "+ to_string(token)+" "+request;
        if(request.substr(0,12)!="sync_tracker"){
            tracker_mutex.lock();
        
            for (const auto& tracker : tracker_info) {
            string ip = tracker.first;
            int port = tracker.second;

            if (ip == current_ip && port == current_port) {
                continue;
            }

            int sock = socket(AF_INET, SOCK_STREAM, 0);
            if (sock < 0) {
                // cerr<<"🔴 Error creating socket to sync with tracker "<<ip<<":"<<port<<"\n";
                continue;
            }

            struct sockaddr_in tracker_addr;
            tracker_addr.sin_family = AF_INET;
            tracker_addr.sin_port = htons(port);

            if (inet_pton(AF_INET, ip.c_str(), &tracker_addr.sin_addr) <= 0) {
                // cerr<<"🔴 Invalid IP address: "<<ip<<"\n";
                close(sock);
                continue;
            }

            if (connect(sock, (struct sockaddr*)&tracker_addr, sizeof(tracker_addr)) < 0) {
                // cerr<<"🔴 Unable to connect to tracker "<<ip<<":"<<port<<"\n";
                close(sock);
                continue;
            }
            cout<<" BEFORE Sync \n";
            
            send(sock, totracker.c_str(), totracker.size(), 0);

            cout<<"🔄 Sync tracker: "<<ip<<":"<<port<<" completed\n";
            close(sock);
        }

        tracker_mutex.unlock();

        }
  
    }
   
      close(clientSocket);
      return 0;
}

void copy_trck(string& file) {
   
    int fd = open(file.c_str(), O_RDONLY);
    if (fd == -1) {
        cerr<<"🔴 Error opening tracker_info file\n";
        exit(1);
    }

    char buffer[256];
    int n;
    string s;

    while ((n = read(fd, buffer, sizeof(buffer) - 1)) > 0) {
        buffer[n] = '\0';
        s += buffer;
    }

    if (n == -1) {
        cerr<<"🔴 Error reading tracker_info file\n";
        close(fd);
        exit(1);
    }

    close(fd);
    int pos = 0;
    int i =1;
    while ((pos = s.find('\n')) != string::npos) {
        string line = s.substr(0, pos);
        s.erase(0, pos + 1);
        // cout<<"tracker file \n"<<flush;
        int colPos = line.find(':');
        if (colPos != string::npos) {
            string ip = line.substr(0, colPos);
            int port = stoi(line.substr(colPos + 1));
            cout<<i<<".ip"<<ip<<port<<flush<<'\n';
            i++;
            tracker_info.push_back({ip, port});
        }
    }
}

void tracker_server(int server_socket,string ip, int port) {
    struct sockaddr_in client_addr;
    socklen_t client_len = sizeof(client_addr);
    int clientSocket;

    while(true){
        clientSocket = accept(server_socket, (struct sockaddr*)&client_addr, &client_len);
        if (clientSocket < 0) {
            if (f) {
                break; 
            }
            cerr<<"🔴 Error on accept\n";
            continue;
        }
        char *clientIp = inet_ntoa(client_addr.sin_addr);
        int clientPort = ntohs(client_addr.sin_port);
        server_logs("✅ Client connected on IP: " + string(clientIp) + " & Port: " + to_string(clientPort) + " 👍");

        thread client_thread(clientReqs, clientSocket, clientPort, clientIp,ip,port);
        client_thread.detach();
    }

    close(server_socket);  
    server_logs("🔴 Server socket closed. Exiting tracker server...\n");
}

void exit_track() {
    string command;
    // while (!f) 
    while(true){
        getline(cin, command);
        if (command == "quit") {
            cout<<"🛑 Tracker shutting down...\n";
            // f = true;
            break;
        }
    }
    exit(0);
}

void sync_with_tracker(const string& tracker_ip, int tracker_port) {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        cerr<<"🔴 Error creating socket for tracker sync.\n";
        return;
    }

    struct sockaddr_in tracker_addr;
    tracker_addr.sin_family = AF_INET;
    tracker_addr.sin_port = htons(tracker_port);
    if (inet_pton(AF_INET, tracker_ip.c_str(), &tracker_addr.sin_addr) <= 0) {
        cerr<<"🔴 Invalid tracker IP: "<<tracker_ip<<"\n";
        close(sockfd);
        return;
    }

    if (connect(sockfd, (struct sockaddr*)&tracker_addr, sizeof(tracker_addr)) < 0) {
        cerr<<"🔴 Unable to connect to tracker "<<tracker_ip<<":"<<tracker_port<<"\n";
        close(sockfd);
        return;
    }
    lock_guard<mutex> lock(tracker_mutex);
    string str = "sync_tracker";
    send(sockfd,str.c_str(),str.size(),0);
    for (const auto& [node_name, info] : node_comm_info) {
        string data_to_send = "sync_node|" + node_name + "|" + info.node_ip + "|" + to_string(info.node_port) + "\n";
        send(sockfd, data_to_send.c_str(), data_to_send.size(), 0);
    }
    for (const auto& [username, password] : users) {
        string data_to_send = "sync_user|" + username + "|" + password + "\n";
        send(sockfd, data_to_send.c_str(), data_to_send.size(), 0);
    }

    for (const auto& [username, client_info] : logged_in_clients) {
        string data_to_send = "sync_client|" + username + "|" + to_string(client_info.ip) + "|" + to_string(client_info.port) + "\n";
        send(sockfd, data_to_send.c_str(), data_to_send.size(), 0);
    }

    for (const auto& [group_id, group_info] : groups) {
        string data_to_send = "sync_group|" + group_id + "|" + group_info.owner + "\n";
        send(sockfd, data_to_send.c_str(), data_to_send.size(), 0);
    }

    for (const auto& [group_id, files] : group_files) {
        for (const auto& [file_name, file_info] : files) {
            string data_to_send = "sync_file|" + group_id + "|" + file_name + "|" + file_info.file_hash + "\n";
            send(sockfd, data_to_send.c_str(), data_to_send.size(), 0);
        }
    }
    for (const auto& [group_id, file_pieces] : group_file_pieces) {
        for (const auto& [file_name, piece_info] : file_pieces) {
            string data_to_send = "sync_piece|" + group_id + "|" + file_name + "|" + to_string(piece_info.total_pieces) + "\n";
            send(sockfd, data_to_send.c_str(), data_to_send.size(), 0);
        }
    }

    
    for (int token : used_tokens) {
        string data_to_send = "sync_token|" + to_string(token) + "|" + tok_user[token] + "\n";
        send(sockfd, data_to_send.c_str(), data_to_send.size(), 0);
    }

    close(sockfd);
    cout<<"🟢 Data synced with tracker "<<tracker_ip<<":"<<tracker_port<<"\n";
}


void sync_thread(string current_ip, int current_port) {
    while (true) {
        this_thread::sleep_for(chrono::seconds(30));  
        tracker_mutex.lock();
        
        for (const auto& tracker : tracker_info) {
            string ip = tracker.first;
            int port = tracker.second;
            if (ip == current_ip && port == current_port) {
                continue;
            }

            
            int sock = socket(AF_INET, SOCK_STREAM, 0);
            if (sock < 0) {
                cerr<<"🔴 Error creating socket to sync with tracker "<<ip<<":"<<port<<"\n";
                continue;
            }

            struct sockaddr_in tracker_addr;
            tracker_addr.sin_family = AF_INET;
            tracker_addr.sin_port = htons(port);
            if (inet_pton(AF_INET, ip.c_str(), &tracker_addr.sin_addr) <= 0) {
                cerr<<"🔴 Invalid IP address: "<<ip<<"\n";
                close(sock);
                continue;
            }

            if (connect(sock, (struct sockaddr*)&tracker_addr, sizeof(tracker_addr)) < 0) {
               // cerr<<"🔴 Connection to tracker "<<ip<<":"<<port<<" failed.\n";
                close(sock);
                continue;
            }

            sync_with_tracker(ip, port);

            close(sock);
        }

        tracker_mutex.unlock();
    }
}




int main(int argc, char** argv) {
    if (argc < 3) {
        cout<< "Usage: ./tracker tracker_info.txt tracker_no\n";
        exit(1);
    }
    int tracker_id = stoi(argv[2]);
    string tracker_file = argv[1];
    tracker_file = "../"+tracker_file;

    // cout<<"tracker id"<<tracker_id<<flush;
    copy_trck(tracker_file);

    if (tracker_id < 1 || tracker_id > tracker_info.size()) {
        cerr<<"🔴 Invalid tracker number.\n";
        exit(1);
    }

    string ip = tracker_info[tracker_id - 1].first;
    int port = tracker_info[tracker_id - 1].second;

    // cout<< "Tracker running on IP: "<<ip<<" Port: "<<port<<"\n";
    server_logs("📈 Tracker started on IP: " + ip + " Port: " + to_string(port));
    int server_socket, clientSocket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);

    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        cerr<<"🔴 Error creating socket\n";
        exit(1);
    }

    bzero((char*)&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(ip.c_str());
    server_addr.sin_port = htons(port);

    int opt = 1;
    if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        cerr<<"🔴 Error setting socket options\n";
        close(server_socket);
        exit(1);
    }

    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        cerr<<"🔴  Error on binding\n";
        close(server_socket);
        exit(1);
    }

    if (listen(server_socket, 15) == 0) {
        server_logs("✅  Listening for connections...");
    } else {
        cerr<<"🔴 Error on listen\n";
    }
    // thread sync_data_thread(sync_thread, ip, port);

    thread input_thread(exit_track);
    
    tracker_server(server_socket,ip, port);
    input_thread.join();
    close(server_socket);
    return 0;
}

