
#include <arpa/inet.h>

#include <fcntl.h>
#include <unistd.h>
#include <iostream>
#include <sstream>
#include <string.h>
#include <vector>
#include <string>
#include <mutex>

#include <sys/socket.h>
#include <sys/stat.h> 
#include <sys/types.h>

#include <openssl/sha.h>
#include <iomanip>
#include <thread>
#include <unordered_map>
#include <set>

using namespace std;
#define bf_size (512 * 1024)
#define csize 512
#define CHUNK_SIZE (512 * 1024)


vector<pair<string, int>> trackr;
unordered_map<string,pair<int,string>> down_files_info;
mutex m;

string compute_sha1(string& data) {
    unsigned char hash[20];
    SHA1(reinterpret_cast< unsigned char*>(data.data()), data.size(), hash);
    stringstream ss;
    for (int i = 0; i < 20; ++i)
        ss<<hex<<setw(2)<<setfill('0')<<(int)hash[i];
    return ss.str();
}
void create_directory(string& destpath) {

    if (mkdir(destpath.c_str(), 0777) == -1) {
        if (errno == EEXIST) {
            cout<<"\nDirectory already exists: "<<destpath <<'\n';
        }else {
            cerr<<"\nError creating directory "<<destpath<<": "<<strerror(errno)<<'\n';
        }
    } else {
        cout<<"\nDirectory created: "<<destpath <<'\n';
    }
}
string upload_file( string& file_path,  string& group_id, int socketfd) {
    int file_desc = open(file_path.data(), O_RDONLY);
    if (file_desc < 0) {
        cerr<<"Error opening file: "<<file_path<<'\n';
        return "Error opening file: ";
    }

    vector<string> hashes;
    char buffer[CHUNK_SIZE];
    long long bytes_read;
    long long file_size = 0;  

    while ((bytes_read = read(file_desc, buffer, sizeof(buffer))) > 0) {
        string chunk(buffer, bytes_read);  
        string hash = compute_sha1(chunk); 
        hashes.push_back(hash);
        file_size += bytes_read;           
        cout<<"\n file size:"<<file_size<<" hash: "<<hash;
    }

    
    if (bytes_read < 0) {
        cerr<<"Error reading file: "<<file_path<<'\n';
        close(file_desc);
        return "Error reading file: ";
    }

    close(file_desc); 

    string concatenated_hashes;
    for ( string& hash : hashes) {
        concatenated_hashes += hash;
    }

    stringstream request;
    string filename = file_path.substr(file_path.find_last_of("/") + 1);
    request <<"upload_file "<<filename<<" "<<file_size<<" "<<concatenated_hashes<<" "<<group_id;
    // cout<<"\n\n upload_file "<<filename<<"\n size: "<<file_size<<"\n hash : "<<concatenated_hashes<<"\n group "<<group_id<<'\n';
    
    string req_str = request.str();
    return req_str;
}


int to_check_tracker( string& ip, int port) {
    int sockfd=-1;
    if (sockfd != -1) {
        close(sockfd);
    }
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        cerr<<"Error creating socket\n";
        return -1;
    }
    struct timeval tv;
    tv.tv_sec = 30;  
    tv.tv_usec = 0;
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, ( char*)&tv, sizeof tv);

    struct sockaddr_in tracker_addr;
    bzero((char*)&tracker_addr, sizeof(tracker_addr));
    tracker_addr.sin_family = AF_INET;
    tracker_addr.sin_addr.s_addr = inet_addr(ip.c_str());
    tracker_addr.sin_port = htons(port);

    if (connect(sockfd, (struct sockaddr*)&tracker_addr, sizeof(tracker_addr)) < 0) {
        cerr<<"Error connecting to tracker: "<<ip<<":"<<to_string(port)<<"\n";
        close(sockfd);
        return -1;
    }

    cout<<"Connected to tracker at IP: "<<ip<<" Port: "<<port<<"\n";
    // cout<<"\n🛡️🛡️ sockfd: "<<sockfd<<"\n";
    return sockfd;
}


string to_tracker(int sockfd,  string& request) {
    m.lock();
    // cout<<"\n inside to_tracker\n";
    int n = send(sockfd, request.c_str(), request.length(),0);
    if (n < 0) {
        cerr<<"Error writing to socket\n";
        m.unlock();
        return "Error";
    }

    char buffer[bf_size];
    bzero(buffer, bf_size);
    n = read(sockfd, buffer, bf_size);
    if(n==0 ){
        cout<<"Connection Closed";
        close(sockfd);
        m.unlock();
        return "Close_client";
    }else if (n < 0) {
        cerr<<"Error reading from socket\n";
        close(sockfd);
        m.unlock();
        return "Error";
    }
    // cout<<"to_tracker function end\n";
    m.unlock();
    return string(buffer);
}


void copy_trck(string& file) {
    int fd = open(file.data(), O_RDONLY);
    if (fd == -1) {
        cerr<<"Error opening tracker_info.txt file\n";
        exit(1);
    }

    char buffer[256];
    int n;
    string s;

    while ((n = read(fd, buffer, sizeof(buffer) - 1)) > 0) {
        buffer[n] = '\0';
        s += buffer;
    }

    if (n == -1) {
        cerr<<"Error reading tracker_info.txt file\n";
        close(fd);
        exit(1);
    }

    close(fd);
    int pos = 0;
    while ((pos = s.find('\n')) != string::npos) {
        string line = s.substr(0, pos);
        s.erase(0, pos + 1);

        int colPos = line.find(':');
        if (colPos != string::npos) {
            string ip = line.substr(0, colPos);
            int port = stoi(line.substr(colPos + 1));
            trackr.push_back({ip, port});
        }
    }
}

void send_piece_to_peer(int peer_socket, string filename, int piece_num) {
    string filepath = "./toupload/"+filename;
    int fd = open(filepath.c_str(), O_RDONLY);
    if (fd < 0) {
        cerr<<"🔴 Error opening file to send piece: "<<filename<<"\n";
        return;
    }

    
    long long piece_size = CHUNK_SIZE;
     long long offset = piece_num * piece_size;

    if (lseek(fd, offset, SEEK_SET) < 0) {
        cerr<<"🔴 Error seeking to offset "<<offset<<" in file: "<<filename<<"\n";
        close(fd);
        return;
    }

    
    char piece_data[CHUNK_SIZE];
    long long bytes_read = read(fd, piece_data, piece_size);
    if (bytes_read > 0) {
        write(peer_socket, piece_data, bytes_read);
    } else {
        cerr<<"🔴 Error reading piece "<<piece_num<<" from file: "<<filename<<"\n";
    }

    close(fd);
}
void handle_peer(int peer_socket) {
    char buffer[CHUNK_SIZE];
    long long n;

    while ((n = read(peer_socket, buffer, sizeof(buffer) - 1)) > 0) {
        buffer[n] = '\0'; 
        cout<<"Peer Requests for:"<<buffer<<"\n";
        
        stringstream ss(buffer);
        string command, filename;
        int piece_num;

        ss>>command>>filename>>piece_num;

        if (command == "file_piece") {
            send_piece_to_peer(peer_socket, filename, piece_num);
        }else{
            string response = "Response from server";
            write(peer_socket, response.data(), response.size());
            cout<<"Send the requested piece\n";
        }
        
    }
    close(peer_socket); 
}
void conn_res(int listen_port) {
    int peer_socket;
    struct sockaddr_in peer_addr;
    socklen_t peer_addr_len = sizeof(peer_addr);

    while (true) {
        peer_socket = accept(listen_port, (struct sockaddr*)&peer_addr, &peer_addr_len);
        if (peer_socket < 0) {
            cerr<<"🔴 Error accepting connection\n";
            continue;
        }
        cout<<"🟢 Accepted connection from "<< inet_ntoa(peer_addr.sin_addr)<<":"<<ntohs(peer_addr.sin_port)<<"\n"<<flush;

        thread handle_peer_thread(handle_peer, peer_socket);
        handle_peer_thread.detach(); 
    }
    close(listen_port); 
}



/************************************************************************ */
void save_piece_to_file(int trackfd, string filename,string destpath, int piece_num,  char* data, long long size) {
    string filepath = "./"+destpath+"/"+filename;
    int fd = open(filepath.c_str(), O_TRUNC|O_WRONLY|O_CREAT,0777);
    if (fd < 0) {
        cerr<<"🔴 Error opening file: "<<filename<<"\n";
        return;
    }

   
    long long piece_size = CHUNK_SIZE; 
     long long offset = piece_num * piece_size;

    
    if (lseek(fd, offset, SEEK_SET) < 0) {
        cerr<<"🔴 Error seeking to offset "<<offset<<" in file: "<<filename<<"\n";
        close(fd);
        return;
    }

    if (write(fd, data, size) < 0) {
        cerr<<"🔴 Error writing piece "<<piece_num<<" to file: "<<filename<<"\n";
    } else {
        cout<<"✅ Successfully wrote piece "<<piece_num<<" to file: "<<filename<<"\n";
        string s;
    }

    close(fd);
}


bool request_piece(int trackfd, string user_ip, int user_port, string filename,string destpath, int piece_num) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        cerr<<"🔴 Error creating socket.\n";
        return false;
    }

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(user_port);
    if (inet_pton(AF_INET, user_ip.c_str(), &server_addr.sin_addr) <= 0) {
        cerr<<"🔴 Invalid IP address: "<<user_ip<<"\n";
        close(sock);
        return false;
    }

    if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        cerr<<"🔴 Connection to "<<user_ip<<":"<<user_port<<" failed.\n";
        close(sock);
        return false;
    }


    string request = "file_piece " + filename + " " + to_string(piece_num) + "\n";
    write(sock, request.c_str(), request.size());


    char buffer[CHUNK_SIZE];
    long long n = read(sock, buffer, sizeof(buffer) - 1);
    if (n > 0) {
        buffer[n] = '\0';
        cout<<"✅ Received piece "<<piece_num<<" from "<<user_ip<<"\n";
        string strbuff(buffer);
        string hashofpiece = compute_sha1(strbuff);
        cout<<"📝 Hash:"<<hashofpiece<<'\n';
        save_piece_to_file(trackfd, filename,destpath, piece_num, buffer, n);
    } else {
        cerr<<"🔴 Error receiving piece "<<piece_num<<" from "<<user_ip<<"\n";
        close(sock);
        return false;
    }
    

    close(sock);
    return true;
}

void connect_to_available_users(int trackfd,unordered_map<string, pair<pair<string, int>, set<int>>> &user_file_info, string filename,string destpath, int total_pieces,string groupid) {

    for (int piece_num = 0; piece_num < total_pieces; ++piece_num) {
        vector<pair<string, pair<string, int>>> users_with_piece;
        for ( auto& entry : user_file_info) {
            string username = entry.first;
            string user_ip = entry.second.first.first;
            int user_port = entry.second.first.second;
             set<int>& pieces = entry.second.second;

            
            if (pieces.find(piece_num) != pieces.end()) {

                users_with_piece.push_back({username, {user_ip, user_port}});
            }
        }

        if (users_with_piece.empty()) {
            cerr<<"No users have piece "<<piece_num<<"\n";
            continue;
        }

        
        srand(time(0));
        int random_index = rand() % users_with_piece.size();
        string selected_user = users_with_piece[random_index].first;
         string& selected_user_ip = users_with_piece[random_index].second.first;
        int selected_user_port = users_with_piece[random_index].second.second;

        cout<<"🔄 Requesting piece "<<piece_num<<" from "<<selected_user<<" at "<<selected_user_ip<<":"<<selected_user_port<<"\n";
        bool success = request_piece(trackfd, selected_user_ip, selected_user_port, filename,destpath, piece_num);
        if (!success) {
            cerr<<"🔴 Failed to download piece "<<piece_num<<" from "<<selected_user<<"\n";
        }
    }
    pair<int,string> pr;
    pr.first = 1;
    pr.second = groupid;
    down_files_info[filename] = pr;

}

void cmd_res(int sockfd, string client_ip_port, string tok = "00") {
    while (true) {
        // cout<<"\n🛡️ sockfd: "<<sockfd<<'\n';
        cout<<": ";
        bool t = true;
        string command, response;
        getline(cin, command);
        cout<<"sending to server\n";

        if (command == "exit") { 
            cout<<"Exiting client.\n";
            int n = send(sockfd, command.c_str(), command.length(),0);

            char buffer[bf_size];
            bzero(buffer, bf_size);
            n = read(sockfd, buffer, bf_size);
            cout<<"Tracker response: "<<buffer<<"\n";
            break;
        }
        command = tok+' '+command;
        if(command.substr(3,13)=="download_file"){
            cout<<"\ninside download\n";
            stringstream sa(command);
            string tok, cmd, group_id, filename, destpath;
            sa>>tok>>cmd>>group_id>>filename>>destpath;
            create_directory(destpath);
            response = to_tracker(sockfd, command);
            unordered_map<string, pair<pair<string, int>, set<int>>> user_file_info;  
            stringstream ss(response);
            string file_name, file_hash;
            long long file_size;
            
            
            getline(ss, group_id, '|');
            getline(ss, file_name, '|');
            ss>>file_size;
            ss.ignore(1);  // Ignore the '|' character
            getline(ss, file_hash, '|');

            
            string user_info_str;

            while (getline(ss, user_info_str, '|')) {
                stringstream user_ss(user_info_str);
                string user, ip_port, pieces_str;

                
                getline(user_ss, user, ',');
                getline(user_ss, ip_port, ',');
                
                
                long long col_pos = ip_port.find(':');
                string user_ip = ip_port.substr(0, col_pos);
                int user_port = stoi(ip_port.substr(col_pos + 1));

                
                set<int> pieces;
                while (getline(user_ss, pieces_str, ':')) {
                    pieces.insert(stoi(pieces_str));
                }
                user_file_info[user] = {{user_ip, user_port}, pieces};
            }
            long long total_pieces = (file_size + CHUNK_SIZE - 1) / CHUNK_SIZE;
            pair<int, string> pr;
            pr.first = 0;
            pr.second = group_id;
            down_files_info[filename] = pr;
            connect_to_available_users(sockfd,user_file_info, file_name,destpath, total_pieces,group_id);


        }else if(command.substr(3,14)=="show_downloads"){
            for(auto it:down_files_info){
                pair<int,string> pr;
                pr = it.second;
                if(pr.first==0) cout<<"\n D";
                else cout<<"\n C";
                cout<<" "<<pr.second<<" "<<it.first;
            }
            cout<<'\n';
        }else if (command.substr(3, 5) == "login"){
            response = to_tracker(sockfd, command);
            stringstream tokss(response);
            string rem;
            int pos = response.find('|');
            tok = response.substr(0,pos);
            rem = response.substr(pos + 1);
            cout<<"Tracker response: "<<rem<<"\n";
                string reg = tok+' '+"my_port "+ client_ip_port;
                string res = to_tracker(sockfd, reg);
                stringstream ss(res);
                cout<<"Tracker response: "<<res<<"\n";
                if(res =="Close_client"|| res == "Error"){
                    close(sockfd);
                    sockfd = -1;
                    for ( auto& tracker : trackr) {
                        sockfd = to_check_tracker(tracker.first, tracker.second);
                        if (sockfd != -1) {
                            break;  
                        }
                    }
                    if (sockfd == -1) {
                        cerr<<"Failed to connect to any other tracker.\n";
                        cout<<" byeee";
                        break;
                        
                    }else{
                        cout<<"\n💡 Please Login first";
                    }
                }            
            }else{

            if (command.substr(3, 11) == "upload_file") {
                stringstream ss(command);
                string tok, cmd, file_path, group_id;

                ss>> tok>> cmd>>file_path>>group_id;
                // cout<<"\n \nyour command"<<flush;
                // //ssddfsd ./toupload/sample.txt
                // cout<<cmd<<" "<<file_path<<" "<<group_id<<flush;
                command = upload_file(file_path, group_id, sockfd); 
                if(command == "Error reading file: "){
                    cout<<"\n Error reading file:";
                    continue; 
                }
                if(command == "Error opening file: "){
                    cout<<"\nError opening file: ";
                    continue;
                }
                command=tok+' '+command;
                // cout<<"\n upload cmd:"<<command<<'\n';
            }
            
            response = to_tracker(sockfd, command);
            cout<<"Tracker response: "<<response<<"\n";
            if(response =="Close_client"|| response == "Error"){
                close(sockfd);
                sockfd = -1;
                for ( auto& tracker : trackr) {
                    sockfd = to_check_tracker(tracker.first, tracker.second);
                    if (sockfd != -1) {
                        break;  
                    }
                }
                if (sockfd == -1) {
                    cerr<<"Failed to connect to any other tracker.\n";
                    cout<<" byeee";
                    break;
                }
                // else{
                //     cout<<"\n💡 Please login first";
                // }
                cout<<"\n🛡️ after sockfd: "<<sockfd<<'\n';
            }
            
        }
        
    }
    exit(0);
}

int main(int argc, char **argv) {
    if (argc < 3) {
        cout<<"Usage: ./client <client IP>:<client PORT> tracker_info.txt\n";
        exit(1);
    }

    string client_ip_port = argv[1];  
    string tracker_file = argv[2];  
    tracker_file = "../"+tracker_file;  
    string ip;
    int port;
    string tok ="00";
    copy_trck(tracker_file);

    int sockfd = -1;
    for (auto& tracker : trackr) {
        cout<<"tracker:"<<tracker.first<<tracker.second<<'\n';
        sockfd = to_check_tracker(tracker.first, tracker.second);
        if (sockfd != -1) {
            break;
        }
    }

    if (sockfd == -1) {
        cerr<<"Can't Connect with any tracker\n";
        exit(1);
    }

    int colPos = client_ip_port.find(':');
    if (colPos != string::npos) {
        ip = client_ip_port.substr(0, colPos);
        port = stoi(client_ip_port.substr(colPos + 1));
    }

    int server_socket;
    struct sockaddr_in server_addr;

    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        cerr<<"🔴 Error creating socket\n";
        exit(1);
    }

    bzero((char*)&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(ip.c_str());
    server_addr.sin_port = htons(port);

    int opt = 1;
    if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        cerr<<"🔴 Error setting socket options\n";
        close(server_socket);
        exit(1);
    }

    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        cerr<<"🔴  Error on binding\n";
        close(server_socket);
        exit(1);
    }

    if (listen(server_socket, 15) == 0) {
        cout<<"✅  Listening for connections...";
    } else {
        cerr<<"🔴 Error on listen\n";
    }

    thread peer_thread(conn_res, server_socket);
    thread input_thread(cmd_res, sockfd, client_ip_port,tok);
    peer_thread.join();
    input_thread.join();
    
    cout<<"  byeeeee \n"<<flush;
    close(sockfd);
    return 0;
}

