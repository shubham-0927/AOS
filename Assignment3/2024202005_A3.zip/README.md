# AOS ASSIGNMENT 3

## To run the code

###  For Trackers:

- Inside tracker folder open terminal.

- Type following in the terminal. 

```
g++ tracker.cpp -o tracker -lpthread

./tracker tracker_info.txt tracker_no
ex: ./tracker tracker_info.txt 1
```

### Clients

- Inside client open terminal.
- Type Following in the terminal.

```shell
g++ client.cpp -o client -lpthread
```

- To run client.

```
./client <IP>:<PORT> tracker_info.txt
ex: ./client 127.0.0.5:8080 tracker_info.txt
```

Create user account

```
create_user <user_id> <passwd>
```

Login: 
```
login <user_id> <passwd>
```
Create Group: 
```
create_group <group_id>
```
Join Group: 
```
join_group <group_id>
```

Leave Group:
```
leave_group <group_id>
```
List pending join: 
```
list_requests <group_id>
```
Accept Group Joining Request:
```
 accept_request <group_id> <user_id>
 ```
List All Group In Network: 
```
list_groups
```
