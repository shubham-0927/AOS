#include<iostream>
#include<stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <string.h>
using namespace std;

struct stat sb;
int create_dir(const char* d){      
    if (stat("Assignment1", &sb) == -1) {
        int f = mkdir("Assignment1", 0766);
        if(f == -1){
            perror("Error number:");
            cout<<'\n';
        }
    }
return 0;
}

int disp_error(int e){
    if(e==-1){
        cout<<"Error Number:";
        cout<<errno<<'\n';
        perror("Program");
        return 1;
    }
    return 0;
}

int reverse_file(int fd,int fdw){
    auto file_size = lseek(fd,0,SEEK_END);
    unsigned long char_written =0;
    long long  a =10;
    char* c = (char*)calloc(2000000, sizeof(char));
    long long c_size =1900000;
    int per;
    while(a>0){
        //read file
        
        long long b = lseek(fd,-char_written,SEEK_END); //b will point to end of every chunk
        
        a = b - c_size; 
        if(a<0) a = 0;
        lseek(fd,a,SEEK_SET);       // a will point to start of previous unread chunk
        long long count;
        if(file_size-char_written<c_size) count = read(fd,c,file_size-char_written);      //check if remaining file size is less than chunk size
        else count = read(fd, c, c_size);
        //write file
        for(long long i = c_size-1;i>=0;i--){
            if((int)c[i]>31 || (int)c[i]==10)
            int e = write(fdw,c+i,1);
            char_written++;
            per = (unsigned int)((100*char_written)/(file_size));
            if(per<100)cout<<'\r'<<per<<'%'<<flush;
            else cout<<'\r'<<99<<'%'<<flush;
        }
    }
    //write(fdw," ",1);  //for adding NULL at the End Of the File
    cout<<'\r'<<100<<'%'<<flush;
    return 0;
}


int rev_interval(long long i,long long j, int fd, int fdw){
    char* c = (char*)calloc(2000000, sizeof(char)); //
    long long end = lseek(fd,0,SEEK_END);
    long long b = lseek(fd,i-1,SEEK_SET);
    unsigned long long beg = 0;
    long long c_size =1900000;
    long long a = 10;
    if(j>end) perror("end pointer is greater than the file size :)");
    while(a>0){
        // cout<<"stage1\n";
        a = b - c_size; //a points to start of the chunk
        if(a<0) a=0; //if remaining file size is then chunk size
        lseek(fd,a,SEEK_SET);
        read(fd,c,b-a+1);
        for(int k=b-a;k>=0;k--){ //writing in the file in reverse order
            write(fdw,c+k,1);
            beg++;
            int per = (unsigned int)((100*beg)/(end));
            if(per<100)cout<<'\r'<<per<<'%'<<flush;
            else cout<<'\r'<<100<<'%'<<flush;
        }
        b = lseek(fd,-beg,SEEK_CUR); //put pointer at end of privious unread chunk
    }
/*---------------------------------------------------------------------------------------------*/
    
    a = lseek(fd,i,SEEK_SET); //put pointer at ith poisition next to read chunks
    // cout<<"a "<<a;
    while(beg<j){           //read from file till jth and write into next file
        // cout<<"stage2\n";
        long long len;
        if(a+c_size<=j){
            len = c_size;
            read(fd,c,c_size);
        }
        else{
            len = j-a+1;
            read(fd,c,len);
        }
        // cout<<"len "<<len;
        write(fdw,c,len);
        beg = beg+len;
        int per = (int)(100*beg)/(end);
        if(per<100)cout<<'\r'<<per<<'%'<<flush;
        else cout<<'\r'<<100<<'%'<<flush;
        a = lseek(fd,a+len,SEEK_SET);
    }

    long long cur = lseek(fd,0,SEEK_CUR); 
/*-------------------------------------------------------------------------------------------*/
    long long p;
    long long len;

    p = lseek(fd,0,SEEK_END);
    unsigned long long cw =0; //cw count byte written by current part
    while(p>a){
        // cout<<"stage3\n";
        long long e = lseek(fd,-cw,SEEK_END);
        p = e - c_size;
        if(p<a) p = a;
        lseek(fd,p,SEEK_SET);
        long long count;
        if((end-a)-cw<c_size) count = read(fd,c,(end-a)-cw);
        else count = read(fd, c, c_size);
        for(long long i = c_size-1;i>=0;i--){
            if(((int)c[i]>31 || (int)c[i]==10))
            write(fdw,c+i,1);
            beg++;
            cw++;
            int per = (int)(100*beg)/(end);
            if(per<100)cout<<'\r'<<per<<'%'<<flush;
            else cout<<'\r'<<99<<'%'<<flush;
        }
    }
    cout<<'\r'<<100<<'%'<<flush;
    return 0;
}


int main(int argc, char **argv){
    string flag = argv[2];
    string filename = argv[1];
    const char* dir = "Assignment1"; //dir name Assignment1(given)
    //create directory and file
    create_dir(dir);
    int fd = open(argv[1], O_RDONLY);
    if(disp_error(fd)) return 0;

    string path = "Assignment1/";
    if(flag == "0") path.append("0_");
    else path.append("1_");
    path.append(filename);
    const char* const_path = &path[0];
    const char* write_filepath;
    //create file

    int fdw = open(const_path,O_WRONLY | O_CREAT |O_TRUNC|O_APPEND,0646);
    if(disp_error(fdw)) return 0;

    if(flag == "0") int x = reverse_file(fd,fdw); //Calling function reverse_file() to reverse the file save it.
    else {
        long long i,j;
        char argv3 = *argv[3],argv4 = *argv[4];
        i = (int)argv3-48;
        //cout<<"i"<<i;
        j = (int)argv4-48;
        //cout<<"j"<<j<<'\n';
        if(j<i){            //Checking if second index is greater than first index
           perror("j<i");
           return -1;
        }
        int x = rev_interval(i,j,fd,fdw);   
    }
    close(fd);          //closing the files
    close(fdw);
    cout<<'\n'; 
    return 0;
}
