# AOS ASSIGNMENT 1

This is readme file for assignment 1 contains instructions to execute the code and the working procedure of the code.

## DIRECTORY STRUCTURE

2024202005_A1<br>
|------2024202005_A1_Q1.cpp<br>
|------2024202005_A1_Q2.cpp <br>
|------README.md

## STEPS TO RUN
### Q1

1. Open Terminal in folder 2024202005_A1
2. Change the ownership of the folder & files to current user

```shell
sudo chown $USER ../2024202005_A1
sudo chown $USER ./*.cpp
```

3. To run 1st program run following:-

```shell
g++ 2024202005_A1_Q1.cpp
```

- `If PERMISSION ERROR persist run below command run command in root user mode by putting sudo in begining of the commands`
- `ex: $sudo g++ 2024202005_A1_Q1.cpp`
- Copy and paste text file you want to reverse in this folder i.e.
<br>2024202005_A1/test.txt

4. To run the program follow below format

```shell
./a.out <input file name> <flag> (either 0 or 1) <start_index> <end_index>
```

- `If PERMISSION ERROR persist run below command run command in root user mode by putting sudo in begining of the commands`

```shell
 ex: $sudo ./a.out test.txt 0
 ```

- Flag 0 : It reverse the whole file and save it at 2024202005_A1/Assignment1/0_test.txt.

```shell
./a.out test.txt 0
```

- Flag 1: It reverse part before first index and part after second index

```shell
./a.out test.txt 1 4 9
```

### Q2

1. Open Terminal in folder 2024202005_A1.
2. Run below command to compile the code.

```shell
g++ 2024202005_A1_Q2.cpp
```

3. To run the program follow below formate.

```shell
./a.out <newfile_path> <oldfile_path> <directory_path>
```
4. Ex: directory structure is like:
``` ./2024202005_A1_Q2.cpp ./oldfile.txt ./Assignment1/newfile.txt```
```shell
./a.out newfile.txt oldfile.txt Assignment1
```


## WORKING PROCEDURE
#### Q1

1. To reverse the whole file :

- Firstly program read files.
- Then create folder if not already there.
- Make file to write in Assingment1 folder.
- Program is reversing the file using function defined(reverse_file()).
- It takes file descripters of read & write files.
- Divide the whole read and write file by chunks(2MB size).
- Read the file from last chunk by moving pointer to the beginning of the current unread last chunk.
- Then putting it into buffer.
- Now write into the file from last character of the buffer.

2. Reversing file by parts

- It has 3 parts.
- first using same logic of reversing file from start to ith index of file.
- Second then read the part between i and j by chunk by chunk and write then directly on the write file.
- Then again using  reversing whole file only for part of file between end of file and jth index.

#### Q2

- In main function fetch file names and directory name.
- Open both files in read mode.
- Seek reading pointer to first byte of last unread chunk of the old file.
- Seek reading pointer to first byte of unread chunk from start of new file.
- Now compare the read buffers.
- perm() function take input the file name for which we are checking the permission and st_mode of stat object of the file.
- This prints the details about permissions of the file.