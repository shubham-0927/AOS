#include<iostream>
#include<stdio.h>
#include <errno.h>
#include <fcntl.h>
#include<bits/stdc++.h>
#include <unistd.h>
#include <sys/stat.h>
#include <string.h>
#include <vector>
using namespace std;

int disp_error(string s,int e){
    if(e==-1){
        cout<<"Error in:"<<s<<"\n";
        cout<<"Error Number:";
        cout<<errno<<'\n';
        perror("Program");
        return 1;
    }
    return 0;
}
void perm(string s,mode_t mode){
    // vector<int> v(9,0);
    if(mode&S_IRUSR) cout<<"\nUser has read permission on "<<s<<": Yes";
    else cout<<"\nUser has read permission on "<<s<<": No";
    if(mode&S_IWUSR) cout<<"\nUser has write permission on "<<s<<": Yes";
    else cout<<"\nUser has read permission on "<<s<<": No";
    if(mode&S_IXUSR) cout<<"\nUser has execute permission on "<<s<<": Yes";
    else cout<<"\nUser has execute permission on "<<s<<": No";
    if(mode&S_IRGRP)cout<<"\nGroup has read permission on "<<s<<": Yes";
    else cout<<"\nGroup has read permission on "<<s<<": No";
    if(mode&S_IWGRP) cout<<"\nGroup has write permission on "<<s<<": Yes";
    else cout<<"\nGroup has write permission on "<<s<<": No";
    if(mode&S_IXGRP) cout<<"\nGroup has execute permission on "<<s<<": Yes";
    else cout<<"\nGroup has execute permission on "<<s<<": No";
    if(mode&S_IROTH) cout<<"\nOthers has read permission on "<<s<<": Yes";
    else cout<<"\nOthers has read permission on "<<s<<": No";
    if(mode&S_IWOTH)cout<<"\nOthers has write permission on "<<s<<": Yes";
    else cout<<"\nOthers has write permission on "<<s<<": No";
    if(mode&S_IXOTH) cout<<"\nOthers has execute permission on "<<s<<": Yes";
    else cout<<"\nOthers has execute permission on "<<s<<": No";
}

int main(int argc, char **argv){
    string nfname = argv[1];
    string ofname = argv[2];
    string dname1 = argv[3];
    string dname2 = argv[3];
    struct stat st;
    if (stat(&dname1[0], &st) == -1){
        cout<<dname1<<": ";
        cout<<"\n No such Directory\n";
        return -1;
    }
    cout<<"\n Directory is created: Yes\n";
    //file read
    string nfpath,ofpath;
    nfpath.append(dname1);
    nfpath.append("/");
    nfpath.append(nfname);
    // ofpath.append(dname2);
    // // cout<<ofpath<<"old file path";
    // ofpath.append("/");
    ofpath.append(ofname);
    // cout<<"second"<<ofpath;
    int fdn = open(&nfpath[0],O_RDONLY);
    if(disp_error(nfpath,fdn)) return -1;
    int fdo = open(&ofpath[0],O_RDONLY);
    if(disp_error(ofpath,fdo)) return -1; 
    
    unsigned long long nfsize = lseek(fdn,0,SEEK_END);
    unsigned long long ofsize = lseek(fdo,0,SEEK_END); //-1 for end of file
    unsigned long long count = ofsize;
    char* c1 = (char*)calloc(2000000, sizeof(char));
    char* c2 = (char*)calloc(2000000, sizeof(char));
    long long c_size = 1900000;      //chunk size
    lseek(fdn,0,SEEK_SET);
    bool same = true;
    unsigned long long s_o=10;
    while(count>0){
        // cout<<"c :"<<count;
        unsigned long long cur_n = lseek(fdn,0,SEEK_CUR);    
        unsigned long long s_n = cur_n+c_size;     //start read pointer for new file
        unsigned long long r_n;
        if(s_n>nfsize){         //check if pointer goes beyond the limit
            s_n = nfsize - cur_n;
            r_n = read(fdn,c1,s_n);
        } 
        else r_n = read(fdn,c1,s_n);

        unsigned long long cur_o = lseek(fdo,0,SEEK_CUR);
        s_o = cur_o - c_size;
        if(s_o<0) s_o=0;
        lseek(fdo,s_o,SEEK_SET);
        long long r_o = read(fdo,c2,cur_o-s_o);

        long long i,j;
        i = 0;
        j = cur_o - s_o-1;
        while(j>=0){
            // if(c2[j]=='\0') j--;
            // if(c1[i]=='\0') i++;
            if(c1[i]!=c2[j]){
                same = false;
                break;
            }
            j--;
            i++;
        }
    count = count - (cur_o-s_o);
    }
    cout<<"\n File content same:";same?cout<<"Yes" : cout<<"No";
    cout<<"\n Both files Sizes are Same: ";
    (nfsize == (ofsize))?cout<<"Yes": cout<<"No";
    //checking permissions
    struct stat nf_st,of_st,dir_st;
    if(stat(&nfpath[0],&nf_st)==-1) perror("stat error new file");
    if(stat(&ofpath[0],&of_st)==-1) perror("stat error old file");
    if(stat(&dname1[0],&dir_st)==-1) perror("stat error directory");
    cout<<"\n\n";
    perm("newfile",nf_st.st_mode);
    cout<<"\n";
    perm("oldfile",of_st.st_mode);
    cout<<"\n";
    perm("directory",dir_st.st_mode);
    cout<<"\n\n";
    close(fdn);
    close(fdo);
    return 0;
}